# anamelClassification > 2024-04-27 9:55am
https://universe.roboflow.com/anamel/anamelclassification

Provided by a Roboflow user
License: CC BY 4.0

